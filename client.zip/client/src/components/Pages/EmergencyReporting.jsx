import React from 'react'
import {HomeNavBar} from '../Layout/NavBar'

export function EmergencyReporting() {
    return (
        <div>
            <HomeNavBar/>
            Emergency Reporting
        </div>
    )
}

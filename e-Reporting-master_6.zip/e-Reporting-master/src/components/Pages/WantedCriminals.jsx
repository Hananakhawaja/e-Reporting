import React from 'react'
import { NavBarPublic } from '../PublicUser/NavBarPublic'
export function WantedCriminals() {
    return (
        <div >
            <NavBarPublic />
            Wanted Criminals
        </div>


    )

}
